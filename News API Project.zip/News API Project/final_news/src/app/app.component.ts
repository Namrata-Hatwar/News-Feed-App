import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { NewsComponent } from './component/news/news.component';
import { NewsService } from './news.service';
import { NavbarComponent } from './component/navbar/navbar.component';
import { isPlatformBrowser } from '@angular/common';
import { NotificationService } from './notification-service.service';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,RouterLink,RouterLinkActive,CommonModule,
    HttpClientModule,NewsComponent,NavbarComponent
  ],
  providers: [NewsService],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  constructor(
    private notificationService: NotificationService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.requestNotificationPermission();
    }
  }

  requestNotificationPermission() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined' && 'Notification' in window) {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          this.notificationService.showNotification("Welcome!", {
            body: "You’ll receive updates about the latest news.",
            icon: 'assets/icons/news-icon.png',
            data: { url: '/' }
          });
        }else if (permission === 'denied') {
          console.log('Notification permission denied');
        }
      });
    }
  }

  
}
