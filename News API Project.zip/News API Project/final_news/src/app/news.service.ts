import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { catchError, interval, map, Observable, of, switchMap } from 'rxjs';
import { NotificationService } from './notification-service.service';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class NewsService {
  private apiKey = 'e468c2f741a445fd962db992b9d4eb82'; // Replace with your News API key
  private apiUrl = 'https://newsapi.org/v2/top-headlines?country=us&apiKey' + this.apiKey;
  private latestArticlePublishedAt: string | null = null; // Track the last article's timestamp

  constructor(private http: HttpClient,
    private notificationService: NotificationService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    // Only call the notification request if the platform is the browser
    if (isPlatformBrowser(this.platformId)) {
      this.requestNotificationPermission();
    }
  }
  requestNotificationPermission() {
    if ('Notification' in window) {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          this.notificationService.showNotification("Welcome!", {
            body: "You’ll receive updates about the latest news.",
            icon: 'assets/icons/news-icon.png'
          });
        }
      });
    }
  }

  getArticlesByCategory(category: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/top-headlines?country=us&category=${category}&apiKey=${this.apiKey}`);

  }
  checkForNewArticles(category: string): Observable<any> {
    return interval(60000) // Check every 60 seconds
      .pipe(
        switchMap(() => this.getArticlesByCategory(category)),
        map(response => {
          if (response.articles && response.articles.length) {
            const latestArticle = response.articles[0];
            if (!this.latestArticlePublishedAt || latestArticle.publishedAt > this.latestArticlePublishedAt) {
              this.latestArticlePublishedAt = latestArticle.publishedAt;
              return latestArticle; // Return the new article if it's more recent
            }
          }
          return null; // No new articles
        }),
        catchError(error => {
          console.error('Error fetching articles:', error);
          return of(null);
        })
      );
  }
}

  
  
