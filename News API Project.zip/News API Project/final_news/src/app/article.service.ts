interface Article {
    id: number;
    title: string;
    description: string;
    url: string;
    urlToImage: string;
    liked?: boolean;
    disliked?: boolean;
    // Add any other fields that your article objects contain
  }
  