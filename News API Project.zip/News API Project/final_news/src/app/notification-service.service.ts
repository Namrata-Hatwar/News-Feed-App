// notification-service.service.ts
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  showNotification(title: string, options?: NotificationOptions): void {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        const notification = new Notification(title, options);
        notification.onclick = () => {
          window.open(options?.data?.url, '_blank');
        };
      } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then(permission => {
          if (permission === 'granted') {
            const notification = new Notification(title, options);
            notification.onclick = () => {
              window.open(options?.data?.url, '_blank');
            };
          }
        });
      }
    }
  }
}
