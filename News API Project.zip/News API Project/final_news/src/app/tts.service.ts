import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TtsService {

  constructor() { }

  speak(text: string): void {
    // Check if SpeechSynthesis is supported in the browser
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);

      // Set some properties (optional)
      utterance.pitch = 1;  // Default is 1 (normal pitch)
      utterance.rate = 1;   // Default is 1 (normal speed)
      utterance.volume = 1; // Default is 1 (full volume)

      // Speak the text
      window.speechSynthesis.speak(utterance);
    } else {
      console.log('Text-to-Speech is not supported in this browser.');
    }
  }

  // Stop any ongoing speech
  stop(): void {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    } else {
      console.log('Text-to-Speech is not supported in this browser.');
    }
  }
}
