import { Component, OnInit } from '@angular/core';
import { NewsService } from '../../news.service';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NavbarComponent } from "../navbar/navbar.component";
import { TtsService } from '../../tts.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-news',
  standalone: true,
  imports: [CommonModule, HttpClientModule, NavbarComponent, FormsModule],
  templateUrl: './news.component.html',
  styleUrl: './news.component.css'
})
export class NewsComponent implements OnInit {
  articles: any[] = [];
  loading: boolean = true;
  newCommentContent: string = '';
  comments: { [articleId: string]: { username: string; content: string }[] } = {};
  reactions: { [articleId: string]: { like: number; dislike: number } } = {};
  isDropdownOpen: { [key: string]: boolean } = {};

  // Track selected reactions for each article
  selectedReactions: { [articleId: string]: 'like' | 'dislike' | null } = {};

  constructor(private newsService: NewsService, private ttsService: TtsService) {}

  ngOnInit() {
    this.fetchArticlesByCategory('general'); // Default category
  }

  fetchArticlesByCategory(category: string) {
    this.loading = true;
    this.newsService.getArticlesByCategory(category).subscribe(data => {
      this.articles = data.articles;
      this.loading = false;

      this.articles.forEach(article => {
        if (!this.reactions[article.id]) {
          this.reactions[article.id] = { like: 0, dislike: 0 };
        }
        if (!this.comments[article.id]) {
          this.comments[article.id] = [];
        }
        this.selectedReactions[article.id] = null;
      });
    });
  }

  readArticle(articleText: string): void {
    this.ttsService.speak(articleText);
  }

  stopReading(): void {
    this.ttsService.stop();
  }

  addReaction(article: any, reactionType: 'like' | 'dislike'): void {
    const articleId = article.id;

    if (!this.reactions[articleId]) {
      this.reactions[articleId] = { like: 0, dislike: 0 };
    }

    // Toggle reaction logic
    if (this.selectedReactions[articleId] === reactionType) {
      // If already selected, undo the reaction
      this.reactions[articleId][reactionType]--;
      this.selectedReactions[articleId] = null;
    } else {
      // If a different reaction, update and reset the other
      if (this.selectedReactions[articleId]) {
        const previousReaction = this.selectedReactions[articleId];
        this.reactions[articleId][previousReaction]--;
      }
      this.reactions[articleId][reactionType]++;
      this.selectedReactions[articleId] = reactionType;
    }
  }

  getReactions(article: any, reactionType: 'like' | 'dislike'): number {
    return this.reactions[article.id] ? this.reactions[article.id][reactionType] : 0;
  }

  toggleDropdown(articleId: string) {
    this.isDropdownOpen[articleId] = !this.isDropdownOpen[articleId];
  }

  shareOnPlatform(article: any, platform: string) {
    const shareUrl = encodeURIComponent(article.url);
    const title = encodeURIComponent(article.title);

    let url = '';
    switch (platform) {
      case 'facebook':
        url = `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`;
        break;
      case 'twitter':
        url = `https://twitter.com/share?url=${shareUrl}&text=${title}`;
        break;
      case 'linkedin':
        url = `https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(article.url).then(() => {
          alert('Link copied to clipboard');
        }).catch(err => {
          console.error('Failed to copy link: ', err);
        });
        return;
      default:
        return;
    }

    window.open(url, '_blank');
  }
}
